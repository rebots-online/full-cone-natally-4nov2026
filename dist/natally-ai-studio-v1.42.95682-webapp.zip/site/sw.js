const RELEASE_ID="7802dda3-4f00-4f77-85c6-d62e4b7aeb94";
const CACHE_NAME="natally-shell-1.42.95682-7802dda3-4f00-4f77-85c6-d62e4b7aeb94";
const PRECACHE_URLS=["/app.html","/assets/App-CRSU-I7n.css","/assets/App-SNBWRUVV.js","/assets/BuildStamp-CjVufAY1.css","/assets/BuildStamp-ClyC0VI-.js","/assets/CreditActions-QPlBuUWU.js","/assets/PurchaseAccess-BHCp9eNx.js","/assets/PurchaseAccess-r1hji0ul.css","/assets/VoiceDownloadStatus-BGV4VCo-.js","/assets/__vite-browser-external-BvNpW4L8.js","/assets/app-BXMXjctl.js","/assets/appIdentity-DWr3tYar.js","/assets/buildIdentity-Crzmg4y7.js","/assets/client-D8-CEssr.js","/assets/firebase-applet-config-uj37n3hE.js","/assets/firebase-znXLIM83.js","/assets/html2canvas-Bw44SOUl.js","/assets/index.es-BAA8G1jA.js","/assets/index.esm-DZXJ54_M.js","/assets/jspdf.es.min-l9d79_W0.js","/assets/marketing-BZwuiUq9.css","/assets/marketing-RMFL6oPl.js","/assets/modulepreload-polyfill-P2Xu9kJm.js","/assets/nativeAuth-C5mtjj2Z.js","/assets/ort-wasm-simd-threaded.asyncify-CxOG5pUO.wasm","/assets/preload-helper-DdDhzPKI.js","/assets/purify.es-Dn3VvdGh.js","/assets/react-AEUQdEwp.js","/assets/react-dom-v8zbhXmG.js","/assets/src-Cq4TGgZf.css","/assets/supertonic.worker-BQarrr-O.js","/assets/supertonicTts-C83AMqL_.js","/assets/swisseph-BqKK9TOX.wasm","/assets/voiceService-BtsghX7L.js","/assets/voiceService-CIRZVdVQ.css","/branding/192x192.png","/branding/512x512.png","/index.html","/landing.html","/manifest.webmanifest","/marketing.html","/pwa.js"];
const SHELL_ROUTES = new Map([["/","/index.html"],["/index.html","/index.html"],["/app.html","/app.html"],["/landing","/landing.html"],["/landing.html","/landing.html"],["/marketing.html","/marketing.html"]]);
const clientReleases = new Map();
const requestedClients = new Set();
let pruning = Promise.resolve();

async function matchesReleaseHtml(response, releaseId) {
  if (!response.ok || !/^(?:text\/html|application\/xhtml\+xml)(?:\s*;|$)/i.test(response.headers.get('content-type') || '')) return false;
  const html = await response.clone().text();
  for (const tag of html.match(/<meta\b[^>]*>/gi) || []) {
    if (!/\sname\s*=\s*(["'])natally-release-id\1/i.test(tag)) continue;
    const content = tag.match(/\scontent\s*=\s*(["'])(.*?)\1/i);
    if (content && content[2].trim()) return !releaseId || content[2].trim() === releaseId;
  }
  return false;
}

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const existed = await caches.has(CACHE_NAME);
    try {
      const cache = await caches.open(CACHE_NAME);
      const results = await Promise.allSettled(PRECACHE_URLS.map(async (path) => {
        const response = await fetch(new Request(path, { cache: 'reload' }));
        if (!response.ok) throw new Error('Precache request failed: ' + path);
        if (Array.from(SHELL_ROUTES.values()).includes(path) && !await matchesReleaseHtml(response, RELEASE_ID)) throw new Error('Precache invocation mismatch: ' + path);
        await cache.put(path, response);
      }));
      const failed = results.find(result => result.status === 'rejected');
      if (failed) throw failed.reason;
      await self.skipWaiting();
    } catch (error) {
      if (!existed) await caches.delete(CACHE_NAME);
      throw error;
    }
  })());
});

function olderShell(name) {
  const own = CACHE_NAME.match(/^natally-shell-(\d+)\.(\d+)\.(\d+)-/);
  const candidate = name.match(/^natally-shell-(\d+)\.(\d+)\.(\d+)-/);
  if (!own || !candidate) return false;
  for (let index = 1; index <= 3; index++) {
    if (Number(candidate[index]) !== Number(own[index])) return Number(candidate[index]) < Number(own[index]);
  }
  // A same/newer-version cache may belong to a worker still installing.
  return false;
}

function pruneUnusedShells() {
  const task = pruning.catch(() => {}).then(async () => {
    const unknownWindows = async () => {
      const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      const liveIds = new Set(windows.map(client => client.id));
      for (const id of clientReleases.keys()) if (!liveIds.has(id)) clientReleases.delete(id);
      for (const id of requestedClients) if (!liveIds.has(id)) requestedClients.delete(id);
      let unknown = false;
      for (const client of windows) {
        if (clientReleases.has(client.id)) continue;
        unknown = true;
        if (!requestedClients.has(client.id)) {
          requestedClients.add(client.id);
          client.postMessage({ type: 'natally:request-release' });
        }
      }
      return unknown;
    };
    if (await unknownWindows()) return;
    const names = await caches.keys();
    for (const name of names.filter(olderShell)) {
      if (await unknownWindows()) return;
      // Read the live reports immediately before deletion. Serialized passes
      // cannot use an earlier snapshot after a newly reported document release.
      if (Array.from(clientReleases.values()).some(id => name.endsWith('-' + id))) continue;
      await caches.delete(name);
    }
  });
  pruning = task;
  return task;
}

self.addEventListener('message', (event) => {
  const source = event.source, data = event.data;
  if (!source || source.type !== 'window' || !source.id || new URL(source.url).origin !== self.location.origin || data?.type !== 'natally:document-release' || typeof data.releaseId !== 'string' || !data.releaseId.trim()) return;
  clientReleases.set(source.id, data.releaseId.trim());
  event.waitUntil(pruneUnusedShells());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    await self.clients.claim();
    await pruneUnusedShells();
  })());
});

async function respondToNavigation(request, shell) {
  try {
    const response = await fetch(new Request(request, { cache: 'reload' }));
    if (!await matchesReleaseHtml(response)) throw new Error('Navigation did not return a release-marked HTML document.');
    if (await matchesReleaseHtml(response, RELEASE_ID)) {
      try { await (await caches.open(CACHE_NAME)).put(shell, response.clone()); } catch (_) { /* The valid online document is still usable if storage is unavailable. */ }
    }
    return response;
  } catch (error) {
    const cached = await (await caches.open(CACHE_NAME)).match(shell);
    if (cached) return cached;
    throw error;
  }
}

async function retainedAsset(request) {
  const path = new URL(request.url).pathname;
  const current = await (await caches.open(CACHE_NAME)).match(path);
  if (current) return current;
  for (const name of (await caches.keys()).filter(name => name.startsWith("natally-shell-") && name !== CACHE_NAME)) {
    const retained = await (await caches.open(name)).match(path);
    if (retained) return retained;
  }
  return fetch(request);
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  const shell = SHELL_ROUTES.get(url.pathname);
  if (shell && request.mode === 'navigate') {
    if (event.clientId) { clientReleases.delete(event.clientId); requestedClients.delete(event.clientId); }
    if (event.resultingClientId) { clientReleases.delete(event.resultingClientId); requestedClients.delete(event.resultingClientId); }
    const response = respondToNavigation(request, shell);
    event.respondWith(response);
    event.waitUntil(response.then(() => pruneUnusedShells(), () => pruneUnusedShells()));
    return;
  }
  if (url.pathname.startsWith('/assets/') && /\.(?:js|css|wasm)$/i.test(url.pathname)) {
    event.respondWith(retainedAsset(request));
    return;
  }
  if (PRECACHE_URLS.includes(url.pathname)) {
    event.respondWith(caches.open(CACHE_NAME).then(cache => cache.match(url.pathname)).then((hit) => hit || fetch(request)));
    return;
  }
});
