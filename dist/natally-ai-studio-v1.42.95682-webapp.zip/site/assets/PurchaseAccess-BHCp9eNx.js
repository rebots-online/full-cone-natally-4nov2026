import{d as e,f as t,n}from"./preload-helper-DdDhzPKI.js";import{t as r}from"./appIdentity-DWr3tYar.js";import{u as i}from"./index.esm-DZXJ54_M.js";import{t as a}from"./firebase-znXLIM83.js";import{a as o,d as s,f as c,i as l,l as u,m as ee,t as d,u as te}from"./CreditActions-QPlBuUWU.js";import{t as f}from"./react-AEUQdEwp.js";import{t as p}from"./react-dom-v8zbhXmG.js";var m=n(),h=t(f(),1),g=p();function _(e,t,n){return n===void 0?{kind:e,sourceSection:t}:{kind:e,sourceSection:t,offerId:n}}var v=[`wav`,`pdf`,`markdown`,`png`,`jpg`,`transcript`];function ne(){return`natally_downloads`}async function re(e){await a.authStateReady();let t=a.currentUser;if(!t)return{state:`unavailable`,message:`Sign in to check an existing purchase. Your reading stays here.`};if(typeof e.resourceId!=`string`||!e.resourceId.trim()||!v.includes(e.format))return{state:`unavailable`,message:`This download is not available.`};try{let e=ne(),n=await u();if(a.currentUser!==t||n.ownerUid!==t.uid)return{state:`unavailable`,message:`The signed-in account changed. Please try again.`};let r=Date.now();if(n.activeEntitlementIds.includes(e)){let t=n.entitlementExpirations[e],i=typeof t==`number`?Math.min(r+6e4,t):r+6e4;if(i<=r)throw Error(`We couldn’t check your purchase. Please try again; no payment has been requested.`);return{state:`owned`,expiresAt:new Date(i).toISOString()}}let i=await te(`reading`);if(a.currentUser!==t||i.ownerUid!==t.uid||!(i.expiresAt>Date.now()))throw Error(`The signed-in account changed. Please try again.`);let o=i.productType===`subscription`?`Subscription${i.billingPeriod?` (billing period ${i.billingPeriod})`:``}. Includes the reading souvenir downloads.`:`One-time purchase. Includes the reading souvenir downloads.`;return{state:`offer`,title:`Choose your reading souvenir`,priceLabel:i.formattedPrice,terms:o,expiresAt:new Date(i.expiresAt).toISOString()}}catch(e){return{state:`unavailable`,message:e instanceof Error?e.message:`We couldn’t check your purchase. Please try again.`}}}var ie=`<!doctype html>\r
<html lang="en">\r
  <head>\r
    <meta charset="UTF-8" />\r
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />\r
    <meta name="color-scheme" content="dark" />\r
    <title>Natally — Choose your experience</title>\r
    <link rel="preconnect" href="https://fonts.googleapis.com" />\r
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />\r
    <link\r
      href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Manrope:wght@400;500;600;700&display=swap"\r
      rel="stylesheet"\r
    />\r
    <style>\r
      :root {\r
        --canvas: #120c1c;\r
        --surface: #1c1428;\r
        --raised: #251a33;\r
        --cream: #f1e8d8;\r
        --muted: #c4b9ce;\r
        --brass: #d4af37;\r
        --line: rgba(196, 185, 206, 0.2);\r
      }\r
      * { box-sizing: border-box; }\r
      html, body { min-height: 100%; }\r
      body {\r
        margin: 0;\r
        background: radial-gradient(circle at 50% 0%, rgba(100, 70, 130, 0.18), transparent 38rem), var(--canvas);\r
        color: var(--cream);\r
        font-family: Manrope, ui-sans-serif, system-ui, sans-serif;\r
        -webkit-font-smoothing: antialiased;\r
      }\r
      button, a { font: inherit; }\r
      button:focus-visible, a:focus-visible { outline: 2px solid var(--brass); outline-offset: 3px; }\r
      .viewport { min-height: 100svh; display: grid; place-items: center; padding: 24px; }\r
      .paywall {\r
        position: relative;\r
        display: grid;\r
        grid-template-columns: minmax(260px, .7fr) minmax(500px, 1.3fr);\r
        width: min(1080px, 100%);\r
        max-height: calc(100svh - 48px);\r
        overflow: hidden;\r
        border: 1px solid var(--line);\r
        border-radius: 24px;\r
        background: var(--surface);\r
        box-shadow: 0 28px 90px rgba(0, 0, 0, .46);\r
      }\r
      .art { position: relative; min-height: 620px; overflow: hidden; background: #181020; }\r
      .art img { width: 100%; height: 100%; display: block; object-fit: cover; object-position: 52% center; }\r
      .art::after {\r
        content: ""; position: absolute; inset: 0;\r
        background: linear-gradient(90deg, transparent 58%, var(--surface)), linear-gradient(0deg, rgba(18, 12, 28, .48), transparent 38%);\r
        pointer-events: none;\r
      }\r
      .brand {\r
        position: absolute; z-index: 1; left: 24px; top: 24px; display: flex; align-items: center; gap: 10px;\r
        font-family: "Instrument Serif", Georgia, serif; font-size: 25px; text-shadow: 0 2px 18px #000;\r
      }\r
      .brand-mark { width: 12px; height: 12px; border: 1px solid var(--brass); border-radius: 50%; background: var(--brass); box-shadow: inset 0 0 0 3px rgba(18, 12, 28, .72); }\r
      .content { min-width: 0; overflow-y: auto; padding: 46px 44px 28px; scrollbar-color: rgba(196, 185, 206, .3) transparent; }\r
      .close {\r
        position: absolute; z-index: 3; top: 14px; right: 14px; width: 36px; height: 36px; border: 1px solid var(--line);\r
        border-radius: 50%; color: var(--cream); background: rgba(18, 12, 28, .76); cursor: pointer; font-size: 22px; line-height: 1;\r
      }\r
      .eyebrow { margin: 0 0 6px; color: var(--brass); font-size: 11px; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; }\r
      h1 { margin: 0; font-family: "Instrument Serif", Georgia, serif; font-size: clamp(38px, 5vw, 54px); font-weight: 400; line-height: .98; letter-spacing: -.02em; }\r
      h1 em { color: var(--brass); font-weight: 400; }\r
      .intro { margin: 10px 0 18px; color: var(--muted); font-size: 14px; line-height: 1.55; }\r
      .screen[hidden] { display: none; }\r
      .offers { display: grid; gap: 12px; }\r
      .offers.compare { grid-template-columns: repeat(2, minmax(0, 1fr)); }\r
      .offer {\r
        width: 100%; min-height: 268px; display: flex; flex-direction: column; align-items: stretch; padding: 20px;\r
        border: 1px solid rgba(212, 175, 55, .48); border-radius: 20px; color: var(--cream); text-align: left;\r
        background: linear-gradient(145deg, rgba(212, 175, 55, .09), transparent 42%), var(--raised);\r
        box-shadow: 0 12px 34px rgba(0, 0, 0, .22); cursor: pointer; transition: border-color .2s, transform .2s, background .2s;\r
      }\r
      .offer:hover:not(:disabled) { transform: translateY(-2px); border-color: var(--brass); background-color: #2b1e3a; }\r
      .offer:disabled { cursor: not-allowed; opacity: .68; }\r
      .offer h2 { margin: 0 0 8px; font-family: "Instrument Serif", Georgia, serif; font-size: 27px; font-weight: 400; line-height: 1.05; }\r
      .offer ul { margin: 0; padding: 0; list-style: none; color: var(--muted); font-size: 12px; line-height: 1.45; }\r
      .offer li { position: relative; margin: 5px 0; padding-left: 17px; }\r
      .offer li::before { content: "✦"; position: absolute; left: 0; color: var(--brass); font-size: 9px; top: 3px; }\r
      .purchase { margin-top: auto; padding-top: 14px; border-top: 1px solid var(--line); }\r
      .price-label { display: block; color: var(--muted); font-size: 10px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }\r
      .price { display: block; margin: 2px 0 8px; font-family: "Instrument Serif", Georgia, serif; font-size: 34px; line-height: 1; color: var(--brass); }\r
      .cta { display: flex; align-items: center; justify-content: space-between; font-size: 13px; font-weight: 700; }\r
      .cta::after { content: "→"; font-size: 18px; }\r
      .billing { display: block; margin-top: 5px; color: var(--muted); font-size: 10px; font-weight: 500; }\r
      .pack-card { display: flex; flex-direction: column; gap: 12px; min-width: 0; }\r
      .pack-select { display: flex; flex-direction: column; gap: 8px; padding: 18px; border: 1px solid rgba(212, 175, 55, .48); border-radius: 20px; background: linear-gradient(145deg, rgba(212, 175, 55, .09), transparent 42%), var(--raised); box-shadow: 0 12px 34px rgba(0, 0, 0, .22); }\r
      .pack-select label { color: var(--muted); font-size: 10px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }\r
      .pack-select select { font: inherit; width: 100%; color: var(--cream); background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 9px 10px; cursor: pointer; }\r
      .pack-select select:focus-visible { outline: 2px solid var(--brass); outline-offset: 3px; }\r
      .pack-select select:disabled { cursor: not-allowed; opacity: .68; }\r
      .compare .offer { min-height: 324px; padding: 18px; }\r
      .compare .offer h2 { font-size: 24px; }\r
      .nav { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-top: 15px; }\r
      .nav-group { display: flex; gap: 8px; }\r
      .nav button, .restore {\r
        border: 0; padding: 7px 2px; color: var(--muted); background: transparent; cursor: pointer; font-size: 12px; font-weight: 600;\r
      }\r
      .nav button:hover, .restore:hover { color: var(--cream); }\r
      .next { color: var(--brass) !important; }\r
      .dots { color: var(--muted); font-size: 10px; letter-spacing: 4px; }\r
      .dots b { color: var(--brass); }\r
      .message { min-height: 18px; margin: 8px 0 0; color: var(--muted); text-align: center; font-size: 11px; }\r
      .legal { margin-top: 8px; color: var(--muted); text-align: center; font-size: 9px; line-height: 1.5; }\r
      .legal a { color: inherit; }\r
      @media (max-width: 760px) {\r
        .viewport { display: block; padding: 0; }\r
        .paywall { display: block; width: 100%; min-height: 100svh; max-height: none; border: 0; border-radius: 0; overflow: visible; }\r
        .art { height: 154px; min-height: 0; }\r
        .art img { object-position: 50% 46%; }\r
        .art::after { background: linear-gradient(0deg, var(--surface), transparent 60%), linear-gradient(90deg, transparent, rgba(28, 20, 40, .28)); }\r
        .brand { top: 18px; left: 20px; }\r
        .content { overflow: visible; padding: 16px 18px 22px; }\r
        h1 { font-size: 39px; }\r
        .intro { margin: 7px 0 12px; font-size: 12px; }\r
        .offer { min-height: 0; padding: 16px; }\r
        .offer h2 { font-size: 24px; }\r
        .offer ul { font-size: 11px; }\r
        .offer li { margin: 3px 0; }\r
        .price { font-size: 30px; margin-bottom: 6px; }\r
        .offers.compare { grid-template-columns: 1fr; }\r
        .compare .offer { min-height: 0; }\r
        .compare .offer h2 { font-size: 21px; }\r
        .compare .purchase { padding-top: 9px; }\r
        .nav { margin-top: 10px; }\r
      }\r
      @media (max-width: 380px) {\r
        .art { height: 126px; }\r
        .content { padding-top: 12px; }\r
        h1 { font-size: 34px; }\r
      }\r
      @media (prefers-reduced-motion: reduce) { .offer { transition: none; } }\r
    </style>\r
  </head>\r
  <body>\r
    <main class="viewport">\r
      <section class="paywall" aria-label="Natally offers">\r
        <button class="close" type="button" aria-label="Close offers">×</button>\r
        <div class="art" aria-hidden="true">\r
          <img src="/paywall/natally-original.webp" alt="" />\r
          <div class="brand"><span class="brand-mark"></span>Natally</div>\r
        </div>\r
        <div class="content">\r
          <div class="screen" data-screen="1">\r
            <p class="eyebrow">A one-time keepsake</p>\r
            <h1 tabindex="-1">Your reading, <em>to keep</em></h1>\r
            <p class="intro">A personal natal reading made for reflection now and revisiting later. Your own interactive astrology encyclopedia, a personal web app preserving your chart, reading, and exploration with Natally, frozen in time and hosted for at least one year, with your clickable chart, planetary chapters, personal questions and answers, and spoken reread.</p>\r
            <div class="offers"></div>\r
          </div>\r
          <div class="screen" data-screen="2" hidden>\r
            <p class="eyebrow">A shared exploration</p>\r
            <h1 tabindex="-1">Follow your <em>curiosity</em></h1>\r
            <p class="intro">Same interactive Natally experience, ready for your questions.</p>\r
            <div class="offers"></div>\r
          </div>\r
          <div class="screen" data-screen="3" hidden>\r
            <p class="eyebrow">Choose your experience</p>\r
            <h1 tabindex="-1">What calls to <em>you?</em></h1>\r
            <p class="intro">Explore with Natally. Add a reading souvenir whenever you like.</p>\r
            <div class="offers compare"></div>\r
          </div>\r
          <nav class="nav" aria-label="Offer screens">\r
            <div class="nav-group"><button class="back" type="button">← Back</button><button class="next" type="button">Next →</button></div>\r
            <span class="dots" aria-label="Screen 1 of 3"></span>\r
            <button class="restore" type="button">Restore purchase</button>\r
          </nav>\r
          <p class="message" aria-live="polite"></p>\r
          <footer class="legal">\r
            <span class="legal-terms"></span>\r
            <a href="https://natally.robin.mba/terms.html" target="_blank" rel="noopener">Terms</a> ·\r
            <a href="https://natally.robin.mba/privacy.html" target="_blank" rel="noopener">Privacy</a> ·\r
            <a href="mailto:support@rochemediaservices.com">Support</a>\r
          </footer>\r
        </div>\r
      </section>\r
    </main>\r
    <script>\r
      (() => {\r
        const state = { prices: { reading: null, conversation: null }, terms: { reading: null, conversation: null }, options: [], selectedOfferId: null, busy: false, message: "", screen: 1 };\r
        const offers = {\r
          reading: {\r
            title: "Natal reading souvenir",\r
            cta: "Buy my reading souvenir",\r
            benefits: [\r
              "Personal reading + extensive PDF, with a chapter per planet",\r
              "Ten exploratory questions to shape your reading",\r
              "Your interactive astrology encyclopedia, frozen in time",\r
              "General astrological background, your reading and voice replay"\r
            ]\r
          },\r
          conversation: {\r
            title: "Experiential co-exploration",\r
            cta: "Buy exploration",\r
            benefits: [\r
              "Roche-funded exploratory conversation with the same interactive Natally",\r
              "Continue with credits for daily horoscopes or synastry",\r
              "Add the one-off reading souvenir whenever you like"\r
            ]\r
          }\r
        };\r
\r
        function emit(name, detail = {}) {\r
          const event = new CustomEvent(\`natally:offer:\${name}\`, { detail, bubbles: true });\r
          document.dispatchEvent(event);\r
          if (window.parent !== window) window.parent.dispatchEvent(new CustomEvent(\`natally:offer:\${name}\`, { detail }));\r
        }\r
\r
        function periodText(period) {\r
          if (typeof period !== "string" || !period) return null;\r
          const match = /^P(\\d+)([DWMY])$/.exec(period.trim());\r
          if (!match) return period;\r
          const count = Number(match[1]);\r
          const units = { D: ["day", "days"], W: ["week", "weeks"], M: ["month", "months"], Y: ["year", "years"] };\r
          const unit = units[match[2]];\r
          if (count === 1) return unit[0] === "day" ? "daily" : unit[0] === "week" ? "weekly" : unit[0] === "month" ? "monthly" : "yearly";\r
          return \`every \${count} \${unit[1]}\`;\r
        }\r
\r
        function termsText(kind) {\r
          const terms = state.terms[kind];\r
          if (!terms) return null;\r
          if (terms.productType === "subscription") {\r
            const period = periodText(terms.billingPeriod);\r
            if (!period) return null;\r
            return \`Subscription\${terms.productTitle ? \`: \${terms.productTitle}\` : ""} · renews automatically, billed \${period}.\`;\r
          }\r
          return \`One-time purchase\${terms.productTitle ? \`: \${terms.productTitle}\` : ""} · never renews.\`;\r
        }\r
\r
        function offerButton(kind) {\r
          const offer = offers[kind];\r
          const price = state.prices[kind];\r
          const terms = state.terms[kind];\r
          const subscriptionBlocked = !!terms && terms.productType === "subscription" && !terms.billingPeriod;\r
          const selectionMissing = kind === "conversation" && !state.options.some((option) => option.offerId === state.selectedOfferId);\r
          const button = document.createElement("button");\r
          button.type = "button";\r
          button.className = "offer";\r
          button.disabled = state.busy || !price || subscriptionBlocked || selectionMissing;\r
          button.dataset.kind = kind;\r
          button.setAttribute("aria-label", \`\${offer.cta}, \${price || "checking price"}\`);\r
          button.innerHTML = \`\r
            <h2>\${offer.title}</h2>\r
            <ul>\${offer.benefits.map((benefit) => \`<li>\${benefit}</li>\`).join("")}</ul>\r
            <span class="purchase">\r
              <span class="price-label"></span>\r
              <strong class="price"></strong>\r
              <span class="cta"></span>\r
              <small class="billing"></small>\r
            </span>\`;\r
          button.querySelector(".price").textContent = price || "Checking price";\r
          button.querySelector(".cta").textContent = state.busy ? "Please wait…" : offer.cta;\r
          button.querySelector(".price-label").textContent = !terms ? "" : terms.productType === "subscription" ? "Subscription price" : "One-time price";\r
          const billing = termsText(kind);\r
          button.querySelector(".billing").textContent = billing || "";\r
          button.addEventListener("click", () => {\r
            if (kind === "conversation") emit("purchase", { kind, offerId: state.selectedOfferId });\r
            else emit("purchase", { kind });\r
          });\r
          return button;\r
        }\r
\r
        // Accessible pack chooser; provider-supplied options only, never local\r
        // price/tier inference. Shares one selection across screens 2 and 3.\r
        function packSelector() {\r
          const wrapper = document.createElement("div");\r
          wrapper.className = "pack-select";\r
          const label = document.createElement("label");\r
          label.textContent = "Choose exploration access";\r
          const select = document.createElement("select");\r
          label.htmlFor = select.id = "natally-pack-select";\r
          if (state.options.length === 0) {\r
            select.disabled = true;\r
            const empty = document.createElement("option");\r
            empty.value = "";\r
            empty.textContent = "No packs available";\r
            select.append(empty);\r
          } else {\r
            const placeholder = document.createElement("option");\r
            placeholder.value = "";\r
            placeholder.textContent = "Select a pack";\r
            placeholder.disabled = true;\r
            select.append(placeholder);\r
            for (const [groupName, prefix] of [["Monthly", "monthly-"], ["One-off packs", "one_time-"]]) {\r
              const group = state.options.filter((option) => option.offerId.startsWith(prefix));\r
              if (group.length === 0) continue;\r
              const optgroup = document.createElement("optgroup");\r
              optgroup.label = groupName;\r
              for (const option of group) {\r
                const element = document.createElement("option");\r
                element.value = option.offerId;\r
                const period = option.productType === "subscription" ? periodText(option.billingPeriod) : null;\r
                element.textContent = \`\${option.productTitle} · \${option.formattedPrice}\${period ? \` · billed \${period}\` : ""}\`;\r
                optgroup.append(element);\r
              }\r
              select.append(optgroup);\r
            }\r
            if (state.selectedOfferId && state.options.some((option) => option.offerId === state.selectedOfferId)) select.value = state.selectedOfferId;\r
          }\r
          if (state.busy) select.disabled = true;\r
          select.addEventListener("change", () => {\r
            if (!select.value) return;\r
            emit("select", { offerId: select.value });\r
          });\r
          wrapper.append(label, select);\r
          return wrapper;\r
        }\r
\r
        function conversationCard() {\r
          const column = document.createElement("div");\r
          column.className = "pack-card";\r
          column.append(packSelector(), offerButton("conversation"));\r
          return column;\r
        }\r
\r
        function render() {\r
          document.querySelectorAll(".screen").forEach((screen) => {\r
            const active = Number(screen.dataset.screen) === state.screen;\r
            screen.hidden = !active;\r
            if (active) {\r
              const container = screen.querySelector(".offers");\r
              container.replaceChildren(...(state.screen === 1 ? [offerButton("reading")] :\r
                state.screen === 2 ? [conversationCard()] :\r
                [offerButton("reading"), conversationCard()]));\r
            }\r
          });\r
          const back = document.querySelector(".back");\r
          const next = document.querySelector(".next");\r
          back.hidden = state.screen === 1;\r
          next.hidden = state.screen === 3;\r
          back.disabled = next.disabled = state.busy;\r
          document.querySelector(".dots").innerHTML = [1, 2, 3].map((n) => n === state.screen ? "<b>●</b>" : "●").join("");\r
          document.querySelector(".dots").setAttribute("aria-label", \`Screen \${state.screen} of 3\`);\r
          document.querySelector(".message").textContent = state.message;\r
          const kinds = state.screen === 1 ? ["reading"] : state.screen === 2 ? ["conversation"] : ["reading", "conversation"];\r
          document.querySelector(".legal-terms").textContent = kinds\r
            .map((kind) => termsText(kind))\r
            .filter(Boolean)\r
            .join(" ");\r
        }\r
\r
        function go(screen) {\r
          state.screen = Math.max(1, Math.min(3, screen));\r
          render();\r
          document.querySelector(\`[data-screen="\${state.screen}"] h1\`).focus?.();\r
        }\r
\r
        document.querySelector(".back").addEventListener("click", () => go(state.screen - 1));\r
        document.querySelector(".next").addEventListener("click", () => go(state.screen + 1));\r
        document.querySelector(".close").addEventListener("click", () => emit("close"));\r
        document.querySelector(".restore").addEventListener("click", () => {\r
          if (state.busy) return;\r
          emit("restore");\r
        });\r
        document.addEventListener("keydown", (event) => {\r
          if (event.key === "Escape") emit("close");\r
          if (state.busy) return;\r
          if (event.key === "ArrowLeft" && state.screen > 1) go(state.screen - 1);\r
          if (event.key === "ArrowRight" && state.screen < 3) go(state.screen + 1);\r
        });\r
\r
        window.NatallyOffers = {\r
          setState(update = {}) {\r
            if (update.prices && typeof update.prices === "object") {\r
              for (const kind of ["reading", "conversation"]) {\r
                if (kind in update.prices) {\r
                  const value = update.prices[kind];\r
                  if (value === null || typeof value === "string") state.prices[kind] = value && value.trim() ? value : null;\r
                }\r
              }\r
            }\r
            if (typeof update.busy === "boolean") state.busy = update.busy;\r
            if (typeof update.message === "string") state.message = update.message;\r
            if ([1, 2, 3].includes(update.screen)) state.screen = update.screen;\r
            if (update.terms && typeof update.terms === "object") {\r
              for (const kind of ["reading", "conversation"]) {\r
                if (!(kind in update.terms)) continue;\r
                const value = update.terms[kind];\r
                if (value === null) { state.terms[kind] = null; continue; }\r
                if (typeof value !== "object") continue;\r
                if (value.productType !== "subscription" && value.productType !== "one_time") { state.terms[kind] = null; continue; }\r
                state.terms[kind] = {\r
                  productType: value.productType,\r
                  billingPeriod: typeof value.billingPeriod === "string" && value.billingPeriod ? value.billingPeriod : null,\r
                  productTitle: typeof value.productTitle === "string" ? value.productTitle : ""\r
                };\r
              }\r
            }\r
            if (Array.isArray(update.options)) {\r
              const seen = new Set();\r
              const options = [];\r
              for (const option of update.options) {\r
                if (!option || typeof option !== "object") continue;\r
                const { offerId, formattedPrice, productTitle, productType, billingPeriod } = option;\r
                if (typeof offerId !== "string" || !offerId || seen.has(offerId)) continue;\r
                if (typeof formattedPrice !== "string" || typeof productTitle !== "string") continue;\r
                if (productType !== "subscription" && productType !== "one_time") continue;\r
                if (billingPeriod !== null && typeof billingPeriod !== "string") continue;\r
                seen.add(offerId);\r
                options.push({ offerId, formattedPrice, productTitle, productType, billingPeriod });\r
              }\r
              state.options = options;\r
            }\r
            if (update.selectedOfferId === null) state.selectedOfferId = null;\r
            else if (typeof update.selectedOfferId === "string" && state.options.some((option) => option.offerId === update.selectedOfferId)) state.selectedOfferId = update.selectedOfferId;\r
            render();\r
          }\r
        };\r
        render();\r
      })();\r
    <\/script>\r
  </body>\r
</html>\r
`,ae=e=>e===`reading`||e===`conversation`;function oe(e){let t=(0,h.useRef)(null),n=(0,h.useRef)(e);n.current=e;let[i,a]=(0,h.useState)(0),o=(0,h.useRef)(-1);return(0,h.useEffect)(()=>{let e=t.current?.contentWindow,r=t.current?.contentDocument;if(!e||!r)return;let i=()=>n.current.options.find(e=>e.offerId===n.current.selectedOfferId)??null,a=e=>{let t=e.detail,r=t?.kind,a=n.current;if(!ae(r)||a.busy||!a.isCurrent()||a.prices[r]===null)return;let o=a.terms[r];if(!o||o.productType===`subscription`&&!o.billingPeriod)return;if(r===`reading`){a.onPurchase(`reading`);return}let s=t?.offerId;typeof s==`string`&&s===a.selectedOfferId&&i()&&a.onPurchase(`conversation`,s)},o=e=>{let t=e.detail?.offerId,r=n.current;typeof t==`string`&&!r.busy&&r.isCurrent()&&r.options.some(e=>e.offerId===t)&&r.onSelect(t)},s=()=>{let e=n.current;!e.busy&&e.isCurrent()&&e.onRestore()},c=()=>n.current.onClose();return r.addEventListener(`natally:offer:purchase`,a),r.addEventListener(`natally:offer:select`,o),r.addEventListener(`natally:offer:restore`,s),r.addEventListener(`natally:offer:close`,c),()=>{r.removeEventListener(`natally:offer:purchase`,a),r.removeEventListener(`natally:offer:select`,o),r.removeEventListener(`natally:offer:restore`,s),r.removeEventListener(`natally:offer:close`,c)}},[i]),(0,h.useEffect)(()=>{let r=e=>{(t.current?.contentWindow)?.NatallyOffers?.setState(e)};o.current===i?r({prices:e.prices,terms:e.terms,options:e.options,selectedOfferId:e.selectedOfferId,busy:e.busy,message:e.message}):(o.current=i,r({prices:n.current.prices,terms:n.current.terms,options:n.current.options,selectedOfferId:n.current.selectedOfferId,busy:n.current.busy,message:n.current.message,screen:n.current.initialScreen??1}))},[i,e.prices,e.terms,e.options,e.selectedOfferId,e.busy,e.message]),(0,m.jsx)(`iframe`,{ref:t,title:`${r} reading purchase options`,className:`natally-paywall-frame`,srcDoc:ie,onLoad:()=>a(e=>e+1)})}var y=e({PurchaseAccessProvider:()=>ce,PurchaseCTA:()=>x,ReadingPurchaseNotice:()=>S,usePurchaseAccess:()=>b}),se=(0,h.createContext)(null);function b(){let e=(0,h.useContext)(se);if(!e)throw Error(`Purchase access provider is missing`);return e}function ce({children:e}){let[t,n]=(0,h.useState)(null),[u,f]=(0,h.useState)({reading:null,conversation:null}),[p,v]=(0,h.useState)({reading:null,conversation:null}),[ne,ie]=(0,h.useState)(!1),[ae,y]=(0,h.useState)(``),[b,ce]=(0,h.useState)(!1),[x,S]=(0,h.useState)([]),[le,C]=(0,h.useState)(null),w=(0,h.useRef)(null),ue=(0,h.useRef)(null),T=(0,h.useRef)(0),E=(0,h.useRef)(0),de=(0,h.useRef)(void 0),D=(0,h.useRef)(!0),O=(0,h.useRef)(!1),k=(0,h.useRef)(!1),A=(0,h.useRef)(null),j=(0,h.useRef)(null),M=(0,h.useRef)(!1),N=(0,h.useRef)({}),P=(0,h.useRef)({}),F=(0,h.useRef)(null),I=(0,h.useRef)(null),L=(0,h.useRef)({reading:null,conversation:null}),R=(0,h.useRef)(0),z=(0,h.useRef)(void 0),B=(0,h.useRef)(null),V=e=>{w.current=e,n(e)},H=e=>{M.current=e,ie(e)},U=e=>!!e&&D.current&&T.current===e.seq&&E.current===e.gen&&e.current()&&(a.currentUser?.uid??null)===e.owner,W=(e,t)=>D.current&&(a.currentUser?.uid??null)===e&&(t===void 0||E.current===t),G=e=>{L.current=e,v(e)},K=()=>{N.current={},P.current={},I.current=null,F.current=null,C(null),S([]),f({reading:null,conversation:null}),G({reading:null,conversation:null})},q=()=>{T.current++,V(null),K(),k.current=!1,H(!1),y(``)},fe=()=>{window.clearTimeout(z.current);let e=[N.current.reading?.expiresAt,...Object.values(P.current).map(e=>e.expiresAt)].filter(e=>typeof e==`number`);if(e.length===0)return;let t=Math.max(0,Math.min(...e)-Date.now());z.current=window.setTimeout(()=>{if(!D.current||O.current)return;let e=w.current;if(!e||!W(e.owner??``)||I.current!==(a.currentUser?.uid??null))return;let t=Object.values(P.current).some(e=>Date.now()>=e.expiresAt),n=N.current.reading!==void 0&&Date.now()>=N.current.reading.expiresAt,r=N.current.conversation,i=r!==void 0&&Date.now()>=r.expiresAt;(t||n||i)&&(n&&(N.current.reading=void 0,f(e=>({...e,reading:null})),G({...L.current,reading:null})),(t||i)&&(f(e=>({...e,conversation:null})),G({...L.current,conversation:null})),Y(e,!1))},t)},J=e=>{let t=e,n=t.productType;return n!==`subscription`&&n!==`one_time`?null:{productType:n,billingPeriod:n===`one_time`||typeof t.billingPeriod!=`string`?null:t.billingPeriod,productTitle:typeof t.productTitle==`string`?t.productTitle:``}},Y=async(e,t=!0)=>{let n=e.owner;if(!n||O.current)return;if(e.kind===`conversation`){y(``);return}let r=++R.current;y(`Checking prices…`);try{let i=await Promise.allSettled([te(`reading`),s(`conversation`)]);if(!D.current||!U(e)||r!==R.current)return;let a={reading:null,conversation:null},o={reading:null,conversation:null},c=!1,l=i[0];if(l.status===`fulfilled`&&l.value.ownerUid===n){let e=l.value;N.current.reading=e,I.current=n;let t=Date.now()>=e.expiresAt;a.reading=t?null:e.formattedPrice,o.reading=t?null:J(e),c=!0}else N.current.reading=void 0;let u={},d=[],p=i[1];if(p.status===`fulfilled`)for(let e of p.value)e.ownerUid!==n||Date.now()>=e.expiresAt||(u[e.offerId]=e,d.push({offerId:e.offerId,formattedPrice:e.formattedPrice,productTitle:e.productTitle,productType:e.productType,billingPeriod:e.billingPeriod}),c=!0);if(!c)throw Error(`The offers could not be loaded. Please try again.`);I.current=n,P.current=u;let m=F.current??e.offerId??null,h=m!==null&&u[m]&&Date.now()<u[m].expiresAt?m:null;!h&&!e.offerId&&(h=ee(d)),F.current=h,C(h),S(d);let g=h===null?void 0:u[h],_=g!==void 0&&Date.now()>=g.expiresAt;N.current.conversation=g,a.conversation=g&&!_?g.formattedPrice:null,o.conversation=g&&!_?J(g):null,f(a),G(o),y(!N.current.reading||d.length===0?`Some prices could not be loaded. Please try again later.`:``),fe();let v=e.kind;if(t&&v&&e.explicitPurchase&&!k.current&&!M.current&&!O.current){if(v===`reading`)(!j.current||j.current.seq!==e.seq)&&(j.current={seq:e.seq,kind:v},Z(e,`reading`));else if(e.offerId){let t=u[e.offerId];t&&Date.now()<t.expiresAt?(!j.current||j.current.seq!==e.seq||j.current.offerId!==e.offerId)&&(j.current={seq:e.seq,kind:v,offerId:e.offerId},Z(e,`conversation`,e.offerId)):y(`The selected pack is currently unavailable. Please choose another pack.`)}}}catch{if(!D.current||!U(e)||r!==R.current)return;K(),y(`The offers could not be loaded. Please try again.`)}},X=async(e,t)=>{let n=e.owner;if(n){if(e.run&&e.request){let t=await re(e.request);if(!U(e)||!W(n,e.gen))return;if(t.state===`owned`){U(e)&&(q(),await e.run());return}U(e)&&y(t.state===`unavailable`?`Your purchase could not be confirmed. Please try again.`:t.title)}else t&&U(e)&&q()}},pe=e=>{let t=w.current;if(!t||!U(t)||M.current||O.current||k.current)return;let n=P.current[e];!n||n.ownerUid!==t.owner||Date.now()>=n.expiresAt||(F.current=e,C(e),N.current.conversation=n,f(e=>({...e,conversation:n.formattedPrice})),G({...L.current,conversation:J(n)}))},Z=async(e,t,n)=>{let r=e.owner;if(O.current||M.current)return;let i=N.current[t],a=L.current[t];if(!r||!i||i.ownerUid!==r||!a||!U(e)||k.current||t===`conversation`&&n!==void 0&&i.offerId!==n)return;if(a.productType===`subscription`&&!a.billingPeriod){y(`Recurring billing details for this offer are unavailable right now. Please try again later.`);return}if(A.current===t&&!k.current){y(`Your purchase is pending with the store. Do not buy again; it will be added automatically as soon as it is confirmed.`);return}if(Date.now()>=i.expiresAt){f(e=>({...e,[t]:null})),Y(e,!1);return}O.current=!0,H(!0),y(`Opening secure checkout…`),ce(!0);let o=!1;try{let n=await c(i);if(!D.current||!W(r,e.gen))return;if(n.state===`cancelled`){o=!0,U(e)&&y(``);return}if(n.state===`pending`){A.current=t,U(e)&&y(`Your payment is pending with the store. It will be added automatically as soon as it is confirmed.`),Q(e,t);return}k.current=!0,A.current===t&&(A.current=null),U(e)&&(f(e=>({...e,[t]:null})),G({...L.current,[t]:null}),y(`Payment confirmed. Updating your purchase…`));let a=await l(r,!0,()=>W(r,e.gen));if(!D.current||!W(r,e.gen))return;window.dispatchEvent(new CustomEvent(`natally:purchase-access-changed`,{detail:{kind:t}}));let s=a.state===`ready`&&!!a.connected;if(a.state!==`ready`){U(e)&&y(`Payment confirmed. Adding it to your account…`),Q(e,t);return}U(e)&&y(`Your purchase is ready.`),await X(e,s);return}catch{D.current&&W(r,e.gen)&&(k.current?(U(e)&&y(`Payment confirmed. Adding it to your account…`),Q(e,t)):(o=!0,U(e)&&y(`Your purchase could not start. Please try again.`)))}finally{O.current=!1,D.current&&T.current===e.seq&&E.current===e.gen&&(H(!1),ce(!1)),o&&U(e)&&!k.current&&Y(e,!1)}},Q=async(e,t)=>{let n=e.owner;if(n){for(let r of[2e3,4e3,8e3,15e3,3e4,6e4]){if(await new Promise(e=>setTimeout(e,r)),!D.current||!W(n,e.gen))return;let i;try{i=await o(n,()=>W(n,e.gen))}catch{continue}if(!D.current||!W(n,e.gen))return;if(i.state===`ready`){A.current===t&&(A.current=null),window.dispatchEvent(new CustomEvent(`natally:purchase-access-changed`,{detail:{kind:t}})),U(e)&&y(`Your purchase is ready.`),await X(e,!!i.connected);return}}U(e)&&y(`Your payment is recorded and is taking longer than usual to arrive. Natally keeps checking automatically each time you open it; you do not need to buy again.`)}},me=async e=>{let t=e.owner;if(t&&!O.current&&!M.current&&U(e)){H(!0),y(k.current?`Checking your purchase…`:`Restoring purchases…`);try{let n=await o(t,()=>W(t,e.gen));if(!D.current||!W(t,e.gen))return;let r=n.state===`ready`&&!!n.connected;if(n.state===`ready`){window.dispatchEvent(new CustomEvent(`natally:purchase-access-changed`,{detail:{kind:e.kind??`reading`}})),U(e)&&y(`Your purchases are up to date.`),await X(e,r);return}U(e)&&y(n.state===`pending`?`A recent purchase is still being confirmed. It will be added automatically.`:n.state===`unfunded`?`Your purchases are up to date. Your balance is empty; add credits to continue.`:`Your purchase records could not be reached just now. Natally will check again automatically.`),await X(e,r)}catch{U(e)&&y(`Your purchases could not be restored. Please try again.`)}finally{D.current&&T.current===e.seq&&E.current===e.gen&&H(!1)}}},he=async e=>{if(e.run&&e.request){H(!1),y(`Checking your purchase…`);try{let t=await re(e.request);if(!U(e))return;if(t.state===`owned`){q(),await e.run();return}y(t.state===`unavailable`?`Your purchase could not be confirmed. Please try again.`:t.title),Y(e,!1)}catch{U(e)&&y(`Your purchase could not be checked. Please try again.`)}}},ge=async(e,t,n=()=>!0)=>{if(O.current)return;let r=a.currentUser?.uid??null,i={seq:++T.current,gen:E.current,kind:e.purchaseIntent?.kind??`reading`,request:e,run:t,current:n,owner:r,explicitPurchase:!1};k.current=!1,K(),V(i),!r||!n()?y(`Sign in to check your purchase. Your reading stays here.`):await he(i)},$=(e=`natal-reading`,t=_(`reading`,`reading-entry`))=>{if(O.current)return;let n=a.currentUser?.uid??null,r={seq:++T.current,gen:E.current,kind:t.kind,offerId:t.offerId,request:{format:`pdf`,resourceId:e,purchaseIntent:t},current:()=>!0,owner:n,explicitPurchase:!0};k.current=!1,K(),V(r),n?Y(r):y(`Sign in to continue your purchase.`)},_e=()=>{if(O.current)return;let e=a.currentUser?.uid??null,t={seq:++T.current,gen:E.current,kind:null,current:()=>!0,owner:e,explicitPurchase:!1};k.current=!1,K(),V(t),e?Y(t,!1):y(`Sign in to see the offers.`)};(0,h.useEffect)(()=>(D.current=!0,()=>{D.current=!1,window.clearTimeout(z.current)}),[]),(0,h.useEffect)(()=>{let e=new URL(window.location.href),t=e.searchParams.get(`offer`),n=e.searchParams.get(`offers`);t===`reading`||t===`conversation`?(e.searchParams.delete(`offer`),B.current={type:`offer`,kind:t}):n===`1`&&(e.searchParams.delete(`offers`),B.current={type:`journey`}),B.current&&window.history.replaceState(window.history.state,``,e.pathname+e.search+e.hash);let r=i(a,e=>{if(!D.current)return;let t=e?.uid??null;if(de.current===t)return;de.current=t,E.current+=1,A.current=null;let n=B.current;if(t&&n){B.current=null,n.type===`offer`?$(n.kind===`reading`?`natal-reading`:`conversation`,_(n.kind,`url-offer`)):_e();return}let r=w.current;if(r){if(r.owner===null&&t&&!O.current){let e={...r,seq:++T.current,gen:E.current,owner:t};V(e),e.run&&e.request?he(e):Y(e,e.explicitPurchase)}else r.owner!==null&&r.owner!==t&&q()}}),o=()=>_e();return window.addEventListener(`natally:show-offers`,o),()=>{r(),window.removeEventListener(`natally:show-offers`,o)}},[]);let ve=!!t&&t.owner!==null;return(0,h.useEffect)(()=>{let e=ue.current;e&&(ve&&!b?e.open||e.showModal():e.open&&e.close())},[ve,b]),(0,m.jsxs)(se.Provider,{value:{requestDownload:ge,showOffer:$,showOffers:_e},children:[e,t&&ve&&t.owner&&(0,g.createPortal)((0,m.jsx)(`dialog`,{ref:ue,className:`natally-offer natally-offer--original`,"aria-label":`${r} purchase options`,onCancel:e=>{e.preventDefault(),q()},children:t.kind===`conversation`?(0,m.jsxs)(`div`,{className:`account-billing p-6`,children:[(0,m.jsxs)(`div`,{className:`account-billing__header`,children:[(0,m.jsx)(`h2`,{children:`Purchases & receipts`}),(0,m.jsx)(`button`,{type:`button`,onClick:q,children:`Close`})]}),(0,m.jsx)(d,{uid:t.owner})]}):(0,m.jsxs)(m.Fragment,{children:[(0,m.jsx)(`button`,{type:`button`,className:`min-h-11 px-4 underline`,onClick:()=>$(`conversation`,_(`conversation`,`purchase-options`)),children:`Buy credits or redeem a code`}),(0,m.jsx)(oe,{ownerUid:t.owner,isCurrent:()=>U(t),prices:u,terms:p,options:x,selectedOfferId:le,busy:ne,message:ae,initialScreen:1,onPurchase:(e,t)=>{if(e===`conversation`){$(`conversation`,_(`conversation`,`purchase-options`));return}let n=w.current;n&&!O.current&&Z(n,e,t)},onSelect:pe,onRestore:()=>{let e=w.current;e&&me(e)},onClose:q})]})}),document.body)]})}function x({kind:e,sourceSection:t,children:n,onOpen:r}){let{showOffer:i}=b();return(0,m.jsx)(`button`,{type:`button`,className:`natally-purchase-cta`,"data-purchase-section":t,"data-purchase-kind":e,onClick:()=>{r?.(),i(e===`reading`?`natal-reading`:`conversation`,_(e,t))},children:n})}function S(){return(0,m.jsxs)(`aside`,{className:`reading-purchase-notice`,children:[(0,m.jsx)(`span`,{children:`Save your reading with the files included in your purchase.`}),(0,m.jsx)(x,{kind:`reading`,sourceSection:`reading-notice`,children:`Buy my reading`})]})}export{_ as i,x as n,b as r,y as t};